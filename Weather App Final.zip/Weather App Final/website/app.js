// Personal API Key for OpenWeatherMap API:  2e07f44c48b27ec3fbbe13fbc41b341c
const apiKey = '2e07f44c48b27ec3fbbe13fbc41b341c&units=imperial';

const baseURL = 'https://api.openweathermap.org/data/2.5/weather?zip='
//&appid=

//Declaere DOM Variables
const newZip = document.getElementById('zipArea').value;
const generate = document.getElementById('generate');
// let feelings = document.getElementById('feelings').value;

//Declare POST request function
const postData = async(url = '', data = {})=>{
    console.log("begin postData function", data);
    const response = await fetch(url, {
        method: 'POST',
        credentials: "same-origin",
        headers: {
            "Content-Type": 'application/json',
        },
        body: JSON.stringify(data)
    })
    try {
        const newData = await response.json();
        console.log("newData is",newData)
        return newData;
    } catch {
    console.log("error:",error);
    }
}

//When "action is performed" call getWeather with 3 params 
function performAction(e){
    const newZip = document.getElementById('zipArea').value;
    console.log("zip is", newZip);
    getWeather(baseURL, newZip, apiKey)

    .then(function(data){
        console.log("data is: ",data);
        const feelings = document.getElementById('feelings').value;
        postData('/projectData', {date: data.dt, temp: data.main.temp, feelings: feelings});
    })

    .then( function() {
        console.log("2nd then reached")
        updateUI()
    });
}

const updateUI = async () => {

    console.log("updateUI reached");
    const projectData = await fetch('/projectData');

    try {

        const dataJSON = await projectData.json();
        console.log("dataJSON on client side is", dataJSON);

        // The OpenWeatherJournal sends the date in a strange format. I looked up the conversion for API date here: 
        // https://stackoverflow.com/questions/65746475/how-to-get-data-info-from-openweathermap-api-dt
        // I want to avoid plagarism so I am acknowleding that I copied the above with minor changes
        
        const badDate = dataJSON.date;
        console.log("badDate is",badDate);
        var day = new Date(badDate*1000);
        console.log("day is ",day);
        var goodDate = day.toDateString();
        console.log("goodDate is ",goodDate);

        const dateElement = document.getElementById('date');
        const tempElement = document.getElementById('temp');
        const contentElement = document.getElementById('content');

        dateElement.innerHTML = goodDate;
        // dateElement.innerHTML = dataJSON.date;
        tempElement.innerHTML = Math.round(dataJSON.temp) + " degrees";
        contentElement.innerHTML = dataJSON.feels;

    } catch {
        console.log("error", error);
    }
}

// Const getWeather function to build the weather API and fetch async
const getWeather = async (baseURL, zip, key)=> {
    
    const res = await fetch(baseURL + zip + "&appid=" + key);

    try {
        const newData = await res.json();
        console.log("newData is", newData);
        return newData;
    } catch {
        console.log("error",error);
    }
}


//Test event Listener
generate.addEventListener('click', ()=> {
    console.log("generate has been clicked");
    performAction();
    });

