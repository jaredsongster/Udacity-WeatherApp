const express = require('express');
const app = express();

app.use(express.static('website'));

const port = 1991;

const data = [];
let projectData = {};

const bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));

const cors = require('cors');
app.use(cors());

app.use(express.static('website'));

const server = app.listen(port, ()=>{
    console.log(`Server is running on port ${port}`)
    console.log('Press Ctrl+C to Stop');
});

app.get('/', (req,res)=>{
    res.sendFile('index.html');
});

app.get('/projectData', (req,res)=> {
    console.log("getcodereached");
    res.json(projectData);
});

app.post('/projectData', (req,res)=>{
    projectData = {
        date: req.body.date,
        temp: req.body.temp,
        feels: req.body.feelings
    }
    console.log("projectData is now: ", projectData);
    res.send(projectData);
});





















// Example POST + GET (get what was posted at a certain URL - dont think test2 is required to be the same URL in the POST and GET)
// app.post('/test2', (req,res)=>{
//     const newEntry = {
//         name: req.body.name,
//         DOB: req.body.DOB
//     }
//     data.push(newEntry);
// });

// app.get('/test2', (req,res)=>{
//     res.send(data[data.length-1]);
// });

